import {
  Controller,
  UseFilters,
  UsePipes,
  ValidationPipe,
} from '@nestjs/common';
import { GrpcMethod } from '@nestjs/microservices';
import { ProductService } from './product.service';
import { ProductServiceControllerMethods } from './protos/product';
import { GrpcExceptionFilter } from 'src/exeptions/grpcExeption.filter';
import { GetProductDto } from './dto/get-product.dto';

@Controller()
@ProductServiceControllerMethods()
@UseFilters(GrpcExceptionFilter)
export class ProductController {
  constructor(private readonly productService: ProductService) {}

  @GrpcMethod('ProductService', 'GetProductList')
  @UsePipes(ValidationPipe)
  async getProductList({ page, limit }: GetProductDto) {
    const { products, total } = await this.productService.getProductList(
      page,
      limit,
    );

    return {
      products: products.map((product) => ({
        id: product.id,
        name: product.name,
        description: product.description,
        price: product.price,
        priceDiscount: product.priceDiscount || 0,
        stock: product.stock,
        imageUrl: product.images,
      })),
      total,
    };
  }
}
