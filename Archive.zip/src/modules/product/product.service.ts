import { HttpException, Injectable } from '@nestjs/common';
import { ProductRepository } from './repositories/product.repository';

@Injectable()
export class ProductService {
  constructor(private readonly productRepository: ProductRepository) {}

  async getProductList(page: number, pageSize: number) {
    if (page == 2) {
      throw new HttpException(
        {
          status: 500,
          message: 'Internal Server',
        },
        500,
      );
    }

    const [products, total] = await this.productRepository.getProducts(
      page,
      pageSize,
    );

    return { products, total };
  }
}
