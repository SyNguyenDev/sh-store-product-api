import { DataSource, Repository } from 'typeorm';
import { Product } from '../entities/product.entity';
import { Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';

@Injectable()
export class ProductRepository extends Repository<Product> {
  constructor(@InjectDataSource() datasource: DataSource) {
    super(Product, datasource.createEntityManager());
  }

  getProducts(page: number, pageSize: number) {
    return this.findAndCount({
      skip: (page - 1) * pageSize,
      take: pageSize,
    });
  }
}
