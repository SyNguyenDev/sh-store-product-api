import { Category } from '../../category/entities/category.entity';
import { Media } from '../../media/entities/media.entity';
import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  OneToMany,
} from 'typeorm';

@Entity('products')
export class Product {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({ type: 'varchar', length: 255 })
  name: string;

  @Column({ type: 'text' })
  description: string;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  price: number;

  @Column({ type: 'decimal', precision: 10, scale: 2, nullable: true })
  priceDiscount: number;

  @Column({ type: 'varchar', length: 50, unique: true })
  sku: string; // Mã định danh sản phẩm

  @Column({ type: 'integer' })
  stock: number;

  @Column({ type: 'timestamp', nullable: true })
  discountStart: Date;

  @Column({ type: 'timestamp', nullable: true })
  discountEnd: Date;

  @ManyToOne(() => Category, (category) => category.products)
  category: Category;

  @Column({ type: 'boolean', default: true })
  isAvailable: boolean;

  @OneToMany(() => Media, (image) => image.id)
  images: Media[];
}
