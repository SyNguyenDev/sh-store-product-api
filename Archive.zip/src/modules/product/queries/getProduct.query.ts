export const GetProducts = `

`;
