import { MigrationInterface, QueryRunner } from 'typeorm';

export class InsertDataCategory1737128816121 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
          INSERT INTO categories (id, name, description)
          VALUES 
          (1, 'Iphone', 'Apple iPhone series'),
          (2, 'Samsung', 'Samsung Galaxy series'),
          (3, 'Xiaomi', 'Xiaomi Redmi and Mi series');
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
          DELETE FROM categories WHERE id IN (
            1,2,3
          );
        `);
  }
}
