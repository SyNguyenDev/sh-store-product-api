import { MigrationInterface, QueryRunner } from 'typeorm';

export class InsertDataMedia1737128937242 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
          INSERT INTO media (id, link)
          VALUES 
          (1, 'https://example.com/images/iphone16-1.jpg'),
          (2, 'https://example.com/images/iphone16-2.jpg'),
          (3, 'https://example.com/images/galaxys25-1.jpg'),
          (4, 'https://example.com/images/mi15-1.jpg');
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
          DELETE FROM product_images WHERE id IN (
            1,2,3,4
          );
        `);
  }
}
