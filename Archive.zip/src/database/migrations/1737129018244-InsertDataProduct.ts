import { MigrationInterface, QueryRunner } from 'typeorm';

export class InsertDataProduct1737129018244 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
          INSERT INTO products (id, name, description, price, "priceDiscount", sku, stock, "mediaId", "discountStart", "discountEnd", "isAvailable", "categoryId")
          VALUES 
          (1, 'iPhone 16', 'Latest iPhone 16 with advanced features', 1500.00, 1300.00, 'IP16-2025', 100, 1, CURRENT_TIMESTAMP, NULL, true, '1'),
          (2, 'Samsung Galaxy S25', 'Samsung flagship phone', 1200.00, 1100.00, 'SGS25-2025', 150, 2, NULL, NULL, true, '2'),
          (3, 'Xiaomi Mi 15', 'Affordable flagship phone from Xiaomi', 800.00, 750.00, 'MI15-2025', 200, 3, NULL, NULL, true, '3');
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
          DELETE FROM products WHERE id IN (
            '1',
            '2',
            '3'
          );
        `);
  }
}
