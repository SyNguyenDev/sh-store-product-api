import {
  MigrationInterface,
  QueryRunner,
  Table,
  TableForeignKey,
} from 'typeorm';

export class CreateProductTable1737127847888 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'products',
        columns: [
          {
            name: 'id',
            type: 'integer',
            isPrimary: true,
            isNullable: false,
          },
          {
            name: 'name',
            type: 'varchar',
            length: '255',
            isNullable: false,
          },
          {
            name: 'description',
            type: 'text',
            isNullable: false,
          },
          {
            name: 'price',
            type: 'decimal',
            precision: 10,
            scale: 2,
            isNullable: false,
          },
          {
            name: 'priceDiscount',
            type: 'decimal',
            precision: 10,
            scale: 2,
          },
          {
            name: 'sku',
            type: 'varchar',
            length: '50',
            isUnique: true,
          },
          {
            name: 'stock',
            type: 'integer',
            isNullable: false,
          },
          {
            name: 'mediaId',
            type: 'integer',
            isNullable: true,
          },
          {
            name: 'discountStart',
            type: 'timestamp',
            isNullable: true,
          },
          {
            name: 'discountEnd',
            type: 'timestamp',
            isNullable: true,
          },
          {
            name: 'isAvailable',
            type: 'boolean',
            default: true,
          },
          {
            name: 'categoryId',
            type: 'integer',
            isNullable: true,
          },
          {
            name: 'createdAt',
            type: 'timestamp',
            default: 'CURRENT_TIMESTAMP',
          },
          {
            name: 'updatedAt',
            type: 'timestamp',
            default: 'CURRENT_TIMESTAMP',
            onUpdate: 'CURRENT_TIMESTAMP',
          },
        ],
      }),
      true,
    );

    await queryRunner.createForeignKey(
      'products',
      new TableForeignKey({
        columnNames: ['categoryId'],
        referencedColumnNames: ['id'],
        referencedTableName: 'categories',
        onDelete: 'SET NULL',
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropForeignKey('products', 'FK_products_categoryId');
    await queryRunner.dropTable('products');
  }
}
