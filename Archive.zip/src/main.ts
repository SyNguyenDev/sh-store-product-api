import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { ClientOptions, Transport } from '@nestjs/microservices';
import { ConfigService } from '@nestjs/config';
import { join } from 'path';
import { AppExceptionFilter } from './exeptions/exeption.filter';
import { ValidationPipe } from '@nestjs/common';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  app.useGlobalPipes(
    new ValidationPipe({
      transform: true,
      validatorPackage: require('@nestjs/class-validator'),
      transformerPackage: require('@nestjs/class-transformer'),
      validationError: {
        target: false,
      },
    }),
  );

  const configService = app.get(ConfigService);

  app.connectMicroservice<ClientOptions>({
    transport: Transport.GRPC,
    options: {
      package: 'product',
      url: configService.get('GRPC_URL'),
      protoPath: [join(__dirname, './modules/product/protos/product.proto')],
      loader: {
        defaults: true,
      },
    },
  });

  app.useGlobalFilters(new AppExceptionFilter());

  app.startAllMicroservices();

  await app.listen(3000, '0.0.0.0');
}
bootstrap();
